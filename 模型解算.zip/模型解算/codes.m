
clear
clc
NN = 1; % 正方体边长 
borderSize=5; % 边界体素预留个数
[vertices, faces, normals] = read_obj2('D:\dam.obj'); %选取你需要读取的obj文件
min_vertex = min(vertices, [], 1); %找到模型xyz最小值
vertices = vertices - min_vertex;  %归0化，避免负数值影响后续计算
[voxels.logical, x, y, z] = voxelization(vertices, faces, NN,borderSize);%体素化
for i =1:size(x,2)   %计算体素中心坐标，为后续计算提供便利
    for j =1:size(y,2)
        for k =1:size(z,2)
            voxels.centerpoint_x(i,j,k)=x(i);
            voxels.centerpoint_y(i,j,k)=y(j);
            voxels.centerpoint_z(i,j,k)=z(k);
        end
    end
end
xx=x;
yy=y;
zz=z;
% [x,y,z] = meshgrid(x, y, z);  
voxel_num=[ size(voxels.centerpoint_x,1)  size(voxels.centerpoint_x,2)  size(voxels.centerpoint_x,3) ];
voxel_size = [NN,NN,NN]; 

for i = 1:voxel_num(1)
    for j = 1:voxel_num(2)
        for k = 1:voxel_num(3)
            % 交换 x 和 z 的位置，y 轴保持不变
            boat(i, k, j) = voxels.logical(i, j, k); % y 轴与 j 互换，x 轴与 i 互换，z 轴与 k 互换
        end
    end
end

xnew = voxel_num(1);
ynew = voxel_num(3);
znew = voxel_num(2); %交换z轴和y轴的取值范围
block_len = NN; %体素边长

%填充内部


for i = 1:xnew
    for j = 1:ynew
        zmin = 0;
        zmax = 0; %暂存最小，最大坐标
        for z = 1:znew
            if boat(i,j,z) == 1
                zmin = z; %找到最小值
                for w = znew:-1:zmin %c从上往下寻找最大值,步长负一
                    if boat(i,j,w) == 1
                        zmax = w;
                        break %找到了就退出
                    end
                end
                break
            end
        end
        if zmax ~= 0
            for s = zmin:zmax
                boat(i,j,s) = 1;
            end
        end
    end
end

%求解参考长度
yMin = ynew;
yMax = 0;
for x = floor(3*xnew/8) : ceil(5*xnew/8)
    for z = 1 : znew
        for y = 1 : ynew
            if boat(x,y,z) == 1
                if y <= yMin
                    yMin = y
                end
                if y >= yMax
                    yMax = y
                end
            end
        end
    end
end
length_resolution = yMax - yMin;

water_block = zeros(xnew,ynew,znew); %水空间

theta = 20;
k = tand(theta) %求解斜率
b_basic = -k*xnew %作用是让所有的水面在水立方下

volumn_of_water = 0;

total_length = 10; %厘米
physic_length = total_length/length_resolution; %每个方块的物理长度等于参考长度除以分辨率
volumn_of_block = physic_length.^3;
density_of_water = 1; %1g每立方厘米
Mass_Boat = 1000; %1.8kg
z = 0;
x = xnew;

if theta < 90
    while density_of_water * volumn_of_water <= Mass_Boat && b_basic <= znew
        for i = 1 : xnew
            for j = 1 : ynew
    
                z = k * i + b_basic % 计算当前的 z 值
                % 
                % % 确保 z 的有效范围
                if z < 1
                     z = 1;
                elseif z > znew
                     z = znew; % 限制 z 的上限
                end
                z
                z = floor(z)
                % 检查 boat 的值
                if boat(i,j,z) == 1
                    volumn_of_water = volumn_of_water + volumn_of_block; % 累加水的体积
                    water_block(i,j,z) = 1; % 将水立方的对应点记录为1
                end
            end
        end
        b_basic = b_basic + 1; % 增加 b_basic 以形成斜面
    end
elseif theta == 90
    while density_of_water * volumn_of_water <= Mass_Boat && x >= 1
        for z = 1 : znew
            for y = 1 : ynew
                if boat(x,y,z) == 1
                     volumn_of_water = volumn_of_water + volumn_of_block; % 累加水的体积
                     water_block(x,y,z) = 1; % 将水立方的对应点记录为1
                end
            end
        end
        x = x - 1;
    end
elseif theta > 90
    k = tan(deg2rad(theta));
    k
    b_basic = znew + abs(k*xnew);
    b_basic
    while density_of_water * volumn_of_water <= Mass_Boat && b_basic >= 0
        for i = 1 : xnew
            for j = 1 : ynew
    
                z = k * i + b_basic % 计算当前的 z 值
                % 
                % % 确保 z 的有效范围
                if z < 1
                     z = 1;
                elseif z > znew
                     z = znew; % 限制 z 的上限
                end
                z
                z = ceil(z)
                % 检查 boat 的值
                if boat(i,j,z) == 1
                    volumn_of_water = volumn_of_water + volumn_of_block; % 累加排水的体积
                    water_block(i,j,z) = 1; % 将水立方的对应点记录为1
                end
            end            
        end
        b_basic = b_basic - 1; % 减少 b_basic 进行遍历
        b_basic
        volumn_of_water
    end
end

%计算浮心
xnew
ynew
znew
COB_X = 0;
COB_Y = 0;
COB_Z = 0;
for x = 1 : xnew
    for y = 1 : ynew
        for z = 1 : znew
            COB_X = COB_X + x*water_block(x,y,z)*volumn_of_block/volumn_of_water;
            COB_Y = COB_Y + y*water_block(x,y,z)*volumn_of_block/volumn_of_water;
            COB_Z = COB_Z + z*water_block(x,y,z)*volumn_of_block/volumn_of_water;
        end
    end
end
COB_X
COB_Y
COB_Z
length_resolution

COB_X_cm = COB_X*physic_length
COB_Y_cm = COB_Y*physic_length
COB_Z_cm = COB_Z*physic_length

COM_X_cm = (xnew/2)*physic_length
COM_Y_cm = COB_Y_cm %只计算翻滚力矩，因此平移
COM_Z_cm = 5.5

rx = COB_X_cm - COM_X_cm;
ry = COB_Z_cm - COM_Z_cm;

buoyance = volumn_of_water*density_of_water/100 %原本的单位是克;

Fx = cosd(theta + 90);
Fy = sind(theta + 90);

torque = buoyance*(rx*Fy - ry*Fx) %单位是N/cm

figure;

for i = 1:voxel_num(1)
    for j = 1:voxel_num(3)
        for k = 1:voxel_num(2)
            if boat(i, j, k) == 1
                % 更新体素的中心坐标
                x = xx(i);
                y = zz(j); % 这里对 y 轴的 k 进行替换
                z = yy(k); % 这里对 z 轴的 j 进行替换

                verticess = [x - NN / 2, y - NN / 2, z - NN / 2;
                             x + NN / 2, y - NN / 2, z - NN / 2;
                             x + NN / 2, y + NN / 2, z - NN / 2;
                             x - NN / 2, y + NN / 2, z - NN / 2;
                             x - NN / 2, y - NN / 2, z + NN / 2;
                             x + NN / 2, y - NN / 2, z + NN / 2;
                             x + NN / 2, y + NN / 2, z + NN / 2;
                             x - NN / 2, y + NN / 2, z + NN / 2];
                % 创建6个面的面索引
                facess = [1, 2, 3, 4; 2, 6, 7, 3; 6, 5, 8, 7; 5, 1, 4, 8; 1, 2, 6, 5; 4, 3, 7, 8];
                % 添加立方体到图形对象
                patch('Vertices', verticess, 'Faces', facess, 'FaceColor', 'cyan', 'EdgeColor', 'black', 'LineWidth', 1);            
            end
        end
    end
end

xlabel('X 坐标');
ylabel('Y 坐标');
zlabel('Z 坐标');
title('Boat 网格可视化');
axis equal;
view(-30, 30);
grid on;
hold off;

figure;

for i = 1:xnew
    for j = 1:ynew
        for k = 1:znew
            if water_block(i, j, k) == 1
                % 更新体素的中心坐标
                x = xx(i);
                y = zz(j); % 这里对 y 轴的 k 进行替换
                z = yy(k); % 这里对 z 轴的 j 进行替换

                verticess = [x - NN / 2, y - NN / 2, z - NN / 2;
                             x + NN / 2, y - NN / 2, z - NN / 2;
                             x + NN / 2, y + NN / 2, z - NN / 2;
                             x - NN / 2, y + NN / 2, z - NN / 2;
                             x - NN / 2, y - NN / 2, z + NN / 2;
                             x + NN / 2, y - NN / 2, z + NN / 2;
                             x + NN / 2, y + NN / 2, z + NN / 2;
                             x - NN / 2, y + NN / 2, z + NN / 2];
                % 创建6个面的面索引
                facess = [1, 2, 3, 4; 2, 6, 7, 3; 6, 5, 8, 7; 5, 1, 4, 8; 1, 2, 6, 5; 4, 3, 7, 8];
                % 添加立方体到图形对象
                patch('Vertices', verticess, 'Faces', facess, 'FaceColor', 'cyan', 'EdgeColor', 'black', 'LineWidth', 1);            
            end
        end
    end
end

xlabel('X 坐标');
ylabel('Y 坐标');
zlabel('Z 坐标');
title(theta,'度排水 网格可视化');
axis equal;
view(-30, 30);
grid on;
hold off;
