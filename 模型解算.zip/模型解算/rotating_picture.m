function torques = rotating_picture(add,NN,total_length,Mass_Boat,density_of_water,COM_Z_cm,cuts)
% add 地址
% NN 精度
% total_length 中间部分的实际长度
% Mass_Boat 船的总质量
% density_of_water 水的密度
% COM_Z_cm 厘米计数下质心高度坐标，因为只计算roll轴
% cuts 切分

angles = linspace(0, 180, cuts);
torques = zeros(size(angles));

borderSize=1; % 边界体素预留个数
[vertices, faces, normals] = read_obj2(add); %选取你需要读取的obj文件
min_vertex = min(vertices, [], 1); %找到模型xyz最小值
vertices = vertices - min_vertex;  %归0化，避免负数值影响后续计算
[voxels.logical, x, y, z] = voxelization(vertices, faces, NN,borderSize);%体素化
for i =1:size(x,2)   %计算体素中心坐标，为后续计算提供便利
    for j =1:size(y,2)
        for k =1:size(z,2)
            voxels.centerpoint_x(i,j,k)=x(i);
            voxels.centerpoint_y(i,j,k)=y(j);
            voxels.centerpoint_z(i,j,k)=z(k);
        end
    end
end
xx=x;
yy=y;
zz=z;
% [x,y,z] = meshgrid(x, y, z);  
voxel_num=[ size(voxels.centerpoint_x,1)  size(voxels.centerpoint_x,2)  size(voxels.centerpoint_x,3) ];
voxel_size = [NN,NN,NN]; 

boat = zeros(voxel_num(1), voxel_num(3), voxel_num(2)); % 0 表示没有体素

% 2. 将 voxels.logical 数据映射到 boat 网格
% 注意这里进行坐标轴转换。
for i = 1:voxel_num(1)
    for j = 1:voxel_num(2)
        for k = 1:voxel_num(3)
            % 交换 x 和 z 的位置，y 轴保持不变
            boat(i, k, j) = voxels.logical(i, j, k); % y 轴与 j 互换，x 轴与 i 互换，z 轴与 k 互换
        end
    end
end

xnew = voxel_num(1);
ynew = voxel_num(3);
znew = voxel_num(2); %交换z轴和y轴的取值范围

%填充内部
for i = 1:xnew
    for j = 1:ynew
        zmin = 0;
        zmax = 0; %暂存最小，最大坐标
        for z = 1:znew
            if boat(i,j,z) == 1
                zmin = z; %找到最小值
                for w = znew:-1:zmin %c从上往下寻找最大值,步长负一
                    if boat(i,j,w) == 1
                        zmax = w;
                        break %找到了就退出
                    end
                end
                break
            end
        end
        if zmax ~= 0
            for s = zmin:zmax
                boat(i,j,s) = 1;
            end
        end
    end
end

%求解参考长度
% yMin = ynew;
% yMax = 0;
% for x = floor(3*xnew/8) : ceil(5*xnew/8)
%     for z = 1 : znew
%         for y = 1 : ynew
%             if boat(x,y,z) == 1
%                 if y <= yMin %比上一个小
%                     yMin = y
%                 end
%                 if y >= yMax %比上一个大
%                     yMax = y
%                 end
%             end
%         end
%     end
% end
% length_resolution = yMax - yMin + 1; %y之差+1等于格子数,因为格子本身占用计数，如1，2，3 -》 3-1+1=3格
physic_length = total_length/ynew; %每个方块的物理长度等于参考长度除以分辨率
volumn_of_block = physic_length.^3; %每个立方体的物理大小


for g = 1:length(angles)
    theta = angles(g);

    water_block = zeros(xnew,ynew,znew); %水空间
    k = tand(theta); %求解斜率
    b_basic = -k*xnew; %作用是让所有的水面在水立方下
    
    volumn_of_water = 0;
    z = 0;
    x = xnew;
    
    temp_layer = zeros(xnew,ynew,znew);

    if theta < 90
        while density_of_water * volumn_of_water <= Mass_Boat && b_basic <= znew
            for i = 1 : xnew
                for j = 1 : ynew
        
                    z = k * i + b_basic % 计算当前的 z 值
                    % 
                    % % 确保 z 的有效范围
                    if z < 1
                         z = 1;
                    elseif z > znew
                         z = znew; % 限制 z 的上限
                    end
                    z
                    z = floor(z)
                    % 检查 boat 的值
                    if boat(i,j,z) == 1
                        volumn_of_water = volumn_of_water + volumn_of_block; % 累加水的体积
                        water_block(i,j,z) = 1; % 将水立方的对应点记录为1
                    end
                end
            end
            b_basic = b_basic + 1; % 增加 b_basic 以形成斜面
        end
    elseif theta == 90
        while density_of_water * volumn_of_water <= Mass_Boat && x >= 1
            for z = 1 : znew
                for y = 1 : ynew
                    if boat(x,y,z) == 1
                         volumn_of_water = volumn_of_water + volumn_of_block; % 累加水的体积
                         water_block(x,y,z) = 1; % 将水立方的对应点记录为1
                    end
                end
            end
            x = x - 1;
        end
    elseif theta > 90
        k = tand(theta);
        b_basic = znew + abs(k*xnew);
        while density_of_water * volumn_of_water <= Mass_Boat && b_basic >= 0
            for i = 1 : xnew
                for j = 1 : ynew
        
                    z = k * i + b_basic % 计算当前的 z 值
                    % 
                    % % 确保 z 的有效范围
                    if z < 1
                         z = 1;
                    elseif z > znew
                         z = znew; % 限制 z 的上限
                    end
                    z
                    z = ceil(z)
                    % 检查 boat 的值
                    if boat(i,j,z) == 1
                        volumn_of_water = volumn_of_water + volumn_of_block; % 累加排水的体积
                        water_block(i,j,z) = 1; % 将水立方的对应点记录为1
                    end
                end            
            end
            b_basic = b_basic - 1; % 减少 b_basic 进行遍历
        end
    end
    
    %计算浮心
    xnew;
    ynew;
    znew;
    COB_X = 0; % x，y，z坐标是格子的坐标，不是实际上的坐标
    COB_Y = 0;
    COB_Z = 0;
    volumn_of_boat = volumn_of_block.*sum(boat(:));
    COM_X_M = 0;
    for x = 1 : xnew
        for y = 1 : ynew
            for z = 1 : znew
                COB_X = COB_X + x*water_block(x,y,z)*volumn_of_block/volumn_of_water;
                COB_Y = COB_Y + y*water_block(x,y,z)*volumn_of_block/volumn_of_water;
                COB_Z = COB_Z + z*water_block(x,y,z)*volumn_of_block/volumn_of_water;
                COM_X_M = COM_X_M + x*boat(x,y,z)*volumn_of_block/volumn_of_boat;  
            end
        end
    end

    COB_X_cm = COB_X*physic_length;
    COB_Y_cm = COB_Y*physic_length;
    COB_Z_cm = COB_Z*physic_length;
    
    disp COM_X;

    COM_X_cm = COM_X_M*physic_length; %
    COM_Y_cm = COB_Y_cm; %只计算翻滚力矩，因此平移

    
    rx = COB_X_cm - COM_X_cm;
    ry = COB_Z_cm - COM_Z_cm;
    
    buoyance = volumn_of_water*density_of_water/100; %原本的单位是克;
    
    Fx = cosd(theta + 90);
    Fy = sind(theta + 90);
    
    torques(g) = buoyance*(rx*Fy - ry*Fx); %单位是N/cm
           
            figure;
            
            for i = 1:xnew
                for j = 1:ynew
                    for k = 1:znew
                        if water_block(i, j, k) == 1
                            % 更新体素的中心坐标
                            x = xx(i);
                            y = zz(j); % 这里对 y 轴的 k 进行替换
                            z = yy(k); % 这里对 z 轴的 j 进行替换
            
                            verticess = [x - NN / 2, y - NN / 2, z - NN / 2;
                                         x + NN / 2, y - NN / 2, z - NN / 2;
                                         x + NN / 2, y + NN / 2, z - NN / 2;
                                         x - NN / 2, y + NN / 2, z - NN / 2;
                                         x - NN / 2, y - NN / 2, z + NN / 2;
                                         x + NN / 2, y - NN / 2, z + NN / 2;
                                         x + NN / 2, y + NN / 2, z + NN / 2;
                                         x - NN / 2, y + NN / 2, z + NN / 2];
                            % 创建6个面的面索引
                            facess = [1, 2, 3, 4; 2, 6, 7, 3; 6, 5, 8, 7; 5, 1, 4, 8; 1, 2, 6, 5; 4, 3, 7, 8];
                            % 添加立方体到图形对象
                            patch('Vertices', verticess, 'Faces', facess, 'FaceColor', 'cyan', 'EdgeColor', 'black', 'LineWidth', 1);            
                        end
                    end
                end
            end
            
            xlabel('X 坐标');
            ylabel('Y 坐标');
            zlabel('Z 坐标');
            title( { ['度数', num2str(theta), '总体积',num2str(volumn_of_water)],['浮心x',num2str(COB_X_cm),'浮心y',num2str(COB_Y_cm),'质心Z',num2str(COM_Z_cm),'质心X',num2str(COM_X_cm)]})
            axis equal;
            view(-30, 30);
            grid on;
            hold off;

    
end

degree = 5;
p = polyfit(angles, torques, degree);

 
           figure;
           for i = 1:voxel_num(1)
                for j = 1:voxel_num(3)
                    for k = 1:voxel_num(2)
                        if boat(i, j, k) == 1
                            % 更新体素的中心坐标
                            x = xx(i);
                            y = zz(j); % 这里对 y 轴的 k 进行替换
                            z = yy(k); % 这里对 z 轴的 j 进行替换
            
                            verticess = [x - NN / 2, y - NN / 2, z - NN / 2;
                                         x + NN / 2, y - NN / 2, z - NN / 2;
                                         x + NN / 2, y + NN / 2, z - NN / 2;
                                         x - NN / 2, y + NN / 2, z - NN / 2;
                                         x - NN / 2, y - NN / 2, z + NN / 2;
                                         x + NN / 2, y - NN / 2, z + NN / 2;
                                         x + NN / 2, y + NN / 2, z + NN / 2;
                                         x - NN / 2, y + NN / 2, z + NN / 2];
                            % 创建6个面的面索引
                            facess = [1, 2, 3, 4; 2, 6, 7, 3; 6, 5, 8, 7; 5, 1, 4, 8; 1, 2, 6, 5; 4, 3, 7, 8];
                            % 添加立方体到图形对象
                            patch('Vertices', verticess, 'Faces', facess, 'FaceColor', 'cyan', 'EdgeColor', 'black', 'LineWidth', 1);            
                        end
                    end
                end
            end
            
            xlabel('X 坐标');
            ylabel('Y 坐标');
            zlabel('Z 坐标');
            title('Boat 网格可视化');
            axis equal;
            view(-30, 30);
            grid on;
            hold off;
            
% 生成拟合曲线
fit_angles = linspace(min(angles), max(angles), 100); % 生成新的角度数据用于拟合曲线
fit_torques = polyval(p, fit_angles); % 计算拟合曲线的对应值

% 绘制原始数据点和拟合曲线
figure;
plot(angles, torques, 'o', 'DisplayName', '原始数据'); % 绘制散点
hold on;
plot(fit_angles, fit_torques, '-', 'DisplayName', '拟合曲线'); % 绘制拟合曲线
xlabel('角度，单位度');
ylabel('回复力矩，单位N/cm');
legend;
grid on;
disp(COM_X_cm)
disp(COB_X_cm)
disp(physic_length)
disp(ynew)
disp(total_length)
end