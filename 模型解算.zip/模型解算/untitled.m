
[x,y,z]=stlread('C:\Users\27652\Desktop\临时文件\zhengti1.0 v2.stl')
patch(x,y,z)

