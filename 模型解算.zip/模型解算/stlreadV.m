function [vertices, faces] = stlreadV(filename)
    % 读入 STL 文件，并返回顶点和面索引
    if nargout > 4
        error('Too many output arguments');
    end

    use_color = (nargout == 4);

    fid = fopen(filename, 'r'); % 打开文件，假设为 STL 二进制格式。
    if fid == -1 
        error('文件无法打开，请检查名称或路径。');
    end

    ftitle = fread(fid, 80, 'uchar=>schar'); % 读取文件标题
    num_facet = fread(fid, 1, 'int32'); % 读取面数

    fprintf('\n标题: %s\n', char(ftitle'));
    fprintf('面数: %d\n', num_facet);

    % 预分配内存以提高运行速度
    vertices = zeros(num_facet * 3, 3); % 顶点数组
    faces = zeros(num_facet, 3); % 面数组

    for i = 1:num_facet
        fread(fid, 3, 'float32'); % 法向量坐标，暂时忽略
        ver1 = fread(fid, 3, 'float32'); % 顶点 1
        ver2 = fread(fid, 3, 'float32'); % 顶点 2
        ver3 = fread(fid, 3, 'float32'); % 顶点 3
        fread(fid, 1, 'uint16'); % 读取颜色字节
        
        % 将顶点存储到数组中
        idx = (i - 1) * 3 + (1:3);
        vertices(idx, :) = [ver1'; ver2'; ver3'];
        faces(i, :) = idx; % 分配面索引
    end

    fclose(fid);

    % 体素化和可视化
    voxelSize = 3; % 自定义体素大小
    [voxelGrid, voxelOrigin] = voxelizeMesh(vertices, faces, voxelSize); % 体素化网格
    visualizeVoxelGrid(voxelGrid, voxelOrigin, voxelSize, vertices); % 可视化体素网格
end

function [voxelGrid, voxelOrigin] = voxelizeMesh(vertices, faces, voxelSize)
    % 体素化网格
    minBound = min(vertices); % 获取最小坐标
    maxBound = max(vertices); % 获取最大坐标
    voxelGridSize = ceil((maxBound - minBound) / voxelSize); % 计算体素网格大小
    voxelGrid = false(voxelGridSize); % 创建空布尔体素网格
    voxelOrigin = minBound; % 存储体素网格的原点坐标

    % 遍历面以填充体素网格
    for i = 1:size(faces, 1)
        triVertices = vertices(faces(i,:), :);
        addVoxelToGrid(triVertices, voxelGrid, voxelOrigin, voxelSize);
    end
end

function addVoxelToGrid(triVertices, voxelGrid, voxelOrigin, voxelSize)
    % 将三角形添加到体素网格中
    xRange = ceil((triVertices(:, 1) - voxelOrigin(1)) / voxelSize);
    yRange = ceil((triVertices(:, 2) - voxelOrigin(2)) / voxelSize);
    zRange = ceil((triVertices(:, 3) - voxelOrigin(3)) / voxelSize);

    % 确保范围在有效索引内
    xRange = max(1, xRange); % 确保不小于1
    yRange = max(1, yRange);
    zRange = max(1, zRange);

    for ix = xRange(:)'
        for iy = yRange(:)'
            for iz = zRange(:)'
                if ix <= size(voxelGrid, 1) && iy <= size(voxelGrid, 2) && iz <= size(voxelGrid, 3)
                    voxelGrid(ix, iy, iz) = true; % 将体素标记为存在
                end
            end
        end
    end
end

function visualizeVoxelGrid(voxelGrid, voxelOrigin, voxelSize, vertices)
    % 可视化体素网格
    [x, y, z] = ind2sub(size(voxelGrid), find(voxelGrid)); % 获取非零体素的索引
    scatter3(x * voxelSize + voxelOrigin(1), y * voxelSize + voxelOrigin(2), z * voxelSize + voxelOrigin(3), 10, 'filled', 'MarkerFaceColor', 'cyan'); % 绘制体素
    hold on;

    % 还原原始模型（可选）
    patch(vertices(:,1), vertices(:,2), vertices(:,3, 'FaceColor', 'none', 'EdgeColor', 'k'); 
    % 可以选择性注释或开启上述行，以同时显示原始网格

    % 设置可视化参数
    xlabel('X 坐标');
    ylabel('Y 坐标');
    zlabel('Z 坐标');
    title('体素化 STL 模型');
    grid on;
    axis equal;

    % 计算三维网格的边界
    xlim([voxelOrigin(1), voxelOrigin(1) + size(voxelGrid, 1) * voxelSize]);
    ylim([voxelOrigin(2), voxelOrigin(2) + size(voxelGrid, 2) * voxelSize]);
    zlim([voxelOrigin(3), voxelOrigin(3) + size(voxelGrid, 3) * voxelSize]);
    view(30, 30); % 设置视角
    hold off;
end
