add = 'C:\Users\28713\Desktop\船体 v3 v3.obj';
NN = 0.3;
total_length = 30;
Mass_Boat = 600;
density_of_water = 1;
COM_X = 12;
COM_Y = 14;
COM_Z = 2;
slices = 20;
map_X = 'x';
map_Y = 'z';
map_Z = 'y';

rotating(add,NN,total_length,Mass_Boat,density_of_water,COM_X,COM_Y,COM_Z,slices,map_X,map_Y,map_Z);