function rotating (add,NN,total_length,Mass_Boat,density_of_water,COM_X,COM_Y,COM_Z,slices,map_X,map_Y,map_Z)
% add 模型地址
% NN 体素精度
% total_length y轴方向上的距离
% Mass_Boat 船的质量
% density_of_water 水的密度
% COM_X 质心x
% COM_Y 质心y
% COM_Z 质心z
% slices 角度切分程度
% map_X 指定哪个体素化后的轴为x轴
% map_Y 指定哪个体素化后的轴为y轴
% map_Z 指定哪个体素化后的轴为z轴

disp('开始计算');
disp('体素化模型');
%体素化模型—————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
borderSize=1; % 边界体素预留个数
[vertices, faces, normals] = read_obj2(add); %选取你需要读取的obj文件
min_vertex = min(vertices, [], 1); %找到模型xyz最小值
vertices = vertices - min_vertex;  %归0化，避免负数值影响后续计算
[voxels.logical, x, y, z] = voxelization(vertices, faces, NN,borderSize);%体素化
for i =1:size(x,2)   %计算体素中心坐标，为后续计算提供便利
    for j =1:size(y,2)
        for k =1:size(z,2)
            voxels.centerpoint_x(i,j,k)=x(i);
            voxels.centerpoint_y(i,j,k)=y(j);
            voxels.centerpoint_z(i,j,k)=z(k);
        end
    end
end
xx=x;
yy=y;
zz=z;
% [x,y,z] = meshgrid(x, y, z);  
voxel_num=[ size(voxels.centerpoint_x,1)  size(voxels.centerpoint_x,2)  size(voxels.centerpoint_x,3) ];
voxel_size = [NN,NN,NN]; 
%体素化结束————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
disp('体素化结束');
disp('重映射');
%重映射模型————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
%%%对轴进行重新映射
if map_X == 'x'||map_X == 'X'
    xnew = voxel_num(1);
elseif map_X == 'y'||map_X == 'Y'
    xnew = voxel_num(2);
else 
    xnew = voxel_num(3);
end

if map_Y == 'x'||map_Y == 'X'
    ynew = voxel_num(1);
elseif map_Y == 'y'||map_Z == 'Y'
    ynew = voxel_num(2);
else 
    ynew = voxel_num(3);
end

if map_Z == 'x'||map_Z == 'X'
    znew = voxel_num(1);
elseif map_Z == 'y'||map_Z == 'Y'
    znew = voxel_num(2);
else 
    znew = voxel_num(3);
end
%%%%——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
%%%计算船体模型
boat = zeros(xnew, ynew, znew); % 0 表示没有体素

for x = 1:voxel_num(1)
    for y = 1:voxel_num(2)
        for z = 1:voxel_num(3)
            boat (x,z,y) = voxels.logical(x,y,z); %这一步的交换需要自己根据实际情况修改
        end
    end
end
%%%填充内部
%%%为了便于计算，请将模型中的船体封闭，避免计算水线出错
for i = 1:xnew
    for j = 1:ynew
        zmin = 0;
        zmax = 0; %暂存最小，最大坐标
        for z = 1:znew
            if boat(i,j,z) == 1
                zmin = z; %找到最小值
                for w = znew:-1:zmin %c从上往下寻找最大值,步长负一
                    if boat(i,j,w) == 1
                        zmax = w;
                        break %找到了就退出
                    end
                end
                break
            end
        end
        if zmax ~= 0
            for s = zmin:zmax
                boat(i,j,s) = 1;
            end
        end
    end
end
%计算几何中心
geometrical_center_x = 0;
geometrical_center_y = 0;
geometrical_center_z = 0;
volumn_of_boat = sum(boat(:));
for l = 1:xnew
    for m = 1:ynew
        for n = 1:znew
            geometrical_center_x = geometrical_center_x + boat(l,m,n)*l/volumn_of_boat;
            geometrical_center_y = geometrical_center_y + boat(l,m,n)*m/volumn_of_boat;
            geometrical_center_z = geometrical_center_z + boat(l,m,n)*n/volumn_of_boat;
        end
    end
end

%重映射结束
%船模可视化———————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
figure;
            
for i = 1:xnew
    for j = 1:ynew
        for k = 1:znew
            if boat(i, j, k) == 1
                % 更新体素的中心坐标
                x = xx(i);
                y = zz(j);
                z = yy(k);

                verticess = [x - NN / 2, y - NN / 2, z - NN / 2;
                             x + NN / 2, y - NN / 2, z - NN / 2;
                             x + NN / 2, y + NN / 2, z - NN / 2;
                             x - NN / 2, y + NN / 2, z - NN / 2;
                             x - NN / 2, y - NN / 2, z + NN / 2;
                             x + NN / 2, y - NN / 2, z + NN / 2;
                             x + NN / 2, y + NN / 2, z + NN / 2;
                             x - NN / 2, y + NN / 2, z + NN / 2];
                % 创建6个面的面索引
                facess = [1, 2, 3, 4; 2, 6, 7, 3; 6, 5, 8, 7; 5, 1, 4, 8; 1, 2, 6, 5; 4, 3, 7, 8];
                % 添加立方体到图形对象
                patch('Vertices', verticess, 'Faces', facess, 'FaceColor', 'cyan', 'EdgeColor', 'black', 'LineWidth', 1);            
            end
        end
    end
end

xlabel('X 坐标');
ylabel('Y 坐标');
zlabel('Z 坐标');
title('船模体素化结果')
axis equal;
view(-30, 30);
grid on;
hold off;
%可视化结束————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
disp('船模映射完成');
disp('开始计算回复力矩')
%回复力矩-角度计算
%接下来的计算中，水面的角度都是相对于xOy平面的，如果水面角度不是你的要求的话，转动模型就是
angles = linspace(0,180,slices); %对计算的角度细分
torques0 = zeros(size(angles)); %存储回复力矩y轴
torques1 = zeros(size(angles)); %存储回复力矩x轴
temp_layer_of_water = zeros(xnew,ynew,znew);%排开的水的最后一层，临时存储
water_block = zeros(xnew,ynew,znew);%排开的水,每次角度更新都要重新归零
physic_length = total_length/ynew;%计算每个格子的物理宽度
volumn_of_voxel = physic_length.^3;%每个格子的物理体积
volumn_of_water = 0;
volumn_of_layer = 0;
geometrical_center_x = geometrical_center_x*physic_length;
geometrical_center_y = geometrical_center_y*physic_length;
geometrical_center_z = geometrical_center_z*physic_length;

COB_X = 0;
COB_Y = 0;
COB_Z = 0;

for index = 1:length(angles)
    theta = angles(index);
    k = tand(theta);%水线斜率
    positive_b_basic = -xnew.*k;%k大于0时候的b基础值，使整个水面的基础位置都在船体之下
    negative_b_basic = znew + abs(k.*xnew);%k小于0时候的b基础值
    water_block(:) = 0;%每次角度变化归零排水区域
    volumn_of_water = 0;
    volumn_of_layer = 0;
    COB_X = 0;
    COB_Y = 0;
    COB_Z = 0;

    if theta < 90
        while 1 > 0
            for x = 1:xnew
                for y = 1:ynew
                    z = k*x + positive_b_basic;
                    %避免z越界
                    if z < 1
                        z = 1;
                    end
                    if z > znew
                        z = znew;
                    end
                    z = floor(z); %z取整，避免索引出错
                    if boat(x,y,z) == 1
                        temp_layer_of_water(x,y,z) = 1;
                        volumn_of_layer = volumn_of_layer + volumn_of_voxel;
                    end
                end
            end
            %现在临时的质量即存在volumn_layer中
            %假如总浮力没有越界，那么体积累积
            if density_of_water*(volumn_of_water + volumn_of_layer) < Mass_Boat
                volumn_of_water = volumn_of_water + volumn_of_layer;%排水体积累积
                water_block = water_block + temp_layer_of_water;%排水网格增大
                temp_layer_of_water(:) = 0;%加上上一层的临时值之后归零
                volumn_of_layer = 0;%重置临时层数值
            else
                value = 0;
                for i = 0:0.05:1
                    if density_of_water*(volumn_of_water + i*volumn_of_layer) >=  Mass_Boat
                        value = i;
                        break
                    end
                end
                volumn_of_water = volumn_of_water + value*volumn_of_layer;%排水体积加权增加
                temp_layer_of_water(:) = value*temp_layer_of_water(:);%临时值加权
                water_block = water_block + temp_layer_of_water;%排水空间扩充，最新一层不填充1
                temp_layer_of_water(:) = 0;%加上上一层的临时值之后归零
                volumn_of_layer = 0;%重置临时层数值
                break
            end
            positive_b_basic = positive_b_basic + 1;%迭代截距
            if positive_b_basic > znew
                %截距比znew都大，说明全部遍历完了都没找到结果
                disp('解算失败，质量过大')
                return
            end
        end
        %循环结束，得到排水体积，以及排水网格
    elseif theta == 90
        x_basic = xnew;
        while 1 > 0
            for z = 1:znew
                for y = 1:ynew
                    %避免z越界
                    if x_basic < 1
                        x_basic = 1;
                    end
                    if x_basic > xnew
                        x_basic = xnew;
                    end

                    if boat(x_basic,y,z) == 1
                        temp_layer_of_water(x_basic,y,z) = 1;
                        volumn_of_layer = volumn_of_layer + volumn_of_voxel;
                    end
                end
            end
            %现在临时的质量即存在volumn_layer中
            %假如总浮力没有越界，那么体积累积
            if density_of_water*(volumn_of_water + volumn_of_layer) < Mass_Boat
                volumn_of_water = volumn_of_water + volumn_of_layer;%排水体积累积
                water_block = water_block + temp_layer_of_water;%排水网格增大
                temp_layer_of_water(:) = 0;%加上上一层的临时值之后归零
                volumn_of_layer = 0;%重置临时层数值
            else
                value = 0;
                for i = 0:0.05:1
                    if density_of_water*(volumn_of_water + i*volumn_of_layer) >=  Mass_Boat
                        value = i;
                        break
                    end
                end
                volumn_of_water = volumn_of_water + value*volumn_of_layer;%排水体积加权增加
                temp_layer_of_water(:) = value*temp_layer_of_water(:);%临时值加权
                water_block = water_block + temp_layer_of_water;%排水空间扩充，最新一层不填充1
                temp_layer_of_water(:) = 0;%加上上一层的临时值之后归零
                volumn_of_layer = 0;%重置临时层数值
                break
            end
            x_basic = x_basic - 1;
            if x_basic < 1
                %截距比znew都大，说明全部遍历完了都没找到结果
                disp('解算失败，质量过大')
                return
            end
        end
        %循环结束，得到排水体积，以及排水网格
    elseif theta > 90
        while 1 > 0
            for x = 1:xnew
                for y = 1:ynew
                    z = k*x + negative_b_basic;
                    %避免z越界
                    if z < 1
                        z = 1;
                    end
                    if z > znew
                        z = znew;
                    end
                    z = ceil(z);%z向上取整，避免索引有误
                    if boat(x,y,z) == 1
                        temp_layer_of_water(x,y,z) = 1;
                        volumn_of_layer = volumn_of_layer + volumn_of_voxel;
                    end
                end
            end
            %现在临时的质量即存在volumn_layer中
            %假如总浮力没有越界，那么体积累积
            if density_of_water*(volumn_of_water + volumn_of_layer) < Mass_Boat
                volumn_of_water = volumn_of_water + volumn_of_layer;%排水体积累积
                water_block = water_block + temp_layer_of_water;%排水网格增大
                temp_layer_of_water(:) = 0;%加上上一层的临时值之后归零
                volumn_of_layer = 0;%重置临时层数值
            else
                value = 0;
                for i = 0:0.05:1
                    if density_of_water*(volumn_of_water + i*volumn_of_layer) >=  Mass_Boat
                        value = i;
                        break
                    end
                end
                volumn_of_water = volumn_of_water + value*volumn_of_layer;%排水体积加权增加
                temp_layer_of_water(:) = value*temp_layer_of_water(:);%临时值加权
                water_block = water_block + temp_layer_of_water;%排水空间扩充，最新一层不填充1
                temp_layer_of_water(:) = 0;%加上上一层的临时值之后归零
                volumn_of_layer = 0;%重置临时层数值
                break
            end
            negative_b_basic = negative_b_basic - 1;%迭代截距
            if negative_b_basic < 1
                %截距比znew都大，说明全部遍历完了都没找到结果
                disp('解算失败，质量过大')
                return
            end
        end
    end
    %开始计算回复力矩——————————————————————————————————————————————————————————————————————————————————————————————————————————————
    for i = 1:xnew
        for j = 1:ynew
            for k = 1:znew
                COB_X = COB_X + i*water_block(i,j,k)*volumn_of_voxel/volumn_of_water;
                COB_Y = COB_Y + j*water_block(i,j,k)*volumn_of_voxel/volumn_of_water;
                COB_Z = COB_Z + k*water_block(i,j,k)*volumn_of_voxel/volumn_of_water;
            end
        end
    end
    COB_X = COB_X*physic_length;
    COB_Y = COB_Y*physic_length;
    COB_Z = COB_Z*physic_length;%将按照体素计的坐标转化为实际尺寸


    rx = COB_X - COM_X;
    ry = COB_Y - COM_Y;
    rz = COB_Z - COM_Z;

    Fx = cosd(theta + 90);
    %Fy = 0; %浮力在y方向没有分力
    Fz = sind(theta + 90);
    
    torques0(index) = density_of_water*volumn_of_water*(rx*Fz - rz*Fx)/100;
    torques1(index) = density_of_water*volumn_of_water*(ry*Fz)/100; %Fy = 0就不写完了
    
    %可视化一下————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
    figure;
            
    for i = 1:xnew
        for j = 1:ynew
            for k = 1:znew
                if water_block(i, j, k) >= 1
                    % 更新体素的中心坐标
                    x = xx(i);
                    y = zz(j); % 这里对 y 轴的 k 进行替换
                    z = yy(k); % 这里对 z 轴的 j 进行替换
    
                    verticess = [x - NN / 2, y - NN / 2, z - NN / 2;
                                 x + NN / 2, y - NN / 2, z - NN / 2;
                                 x + NN / 2, y + NN / 2, z - NN / 2;
                                 x - NN / 2, y + NN / 2, z - NN / 2;
                                 x - NN / 2, y - NN / 2, z + NN / 2;
                                 x + NN / 2, y - NN / 2, z + NN / 2;
                                 x + NN / 2, y + NN / 2, z + NN / 2;
                                 x - NN / 2, y + NN / 2, z + NN / 2];
                    % 创建6个面的面索引
                    facess = [1, 2, 3, 4; 2, 6, 7, 3; 6, 5, 8, 7; 5, 1, 4, 8; 1, 2, 6, 5; 4, 3, 7, 8];
                    % 添加立方体到图形对象
                    patch('Vertices', verticess, 'Faces', facess, 'FaceColor', 'cyan', 'EdgeColor', 'black', 'LineWidth', 1);            
                end
            end
        end
    end
    
    xlabel('X 坐标');
    ylabel('Y 坐标');
    zlabel('Z 坐标');
    title( { ['角度', num2str(theta), '排水体积',num2str(volumn_of_water),'浮力',num2str(density_of_water*volumn_of_water)],['浮心x',num2str(COB_X),'浮心y',num2str(COB_Y),'浮心z',num2str(COB_Z)],['几何中心x',num2str(geometrical_center_x), ...
        '几何中心y',num2str(geometrical_center_y),'几何中心z',num2str(geometrical_center_z)],['质心x',num2str(COM_X),'质心y',num2str(COM_Y),'质心z',num2str(COM_Z)]})
    axis equal;
    view(-30, 30);
    grid on;
    hold off;
    disp('剩余解算次数:');
    disp(num2str(slices - index));
end
disp('生成图像...');
degree = 8;
p0 = polyfit(angles, torques0, degree);
p1 = polyfit(angles, torques1, degree);

fit_angles = linspace(min(angles), max(angles), 100); % 生成新的角度数据用于拟合曲线
fit_torques0 = polyval(p0, fit_angles); % 计算拟合曲线的对应值
fit_torques1 = polyval(p1, fit_angles); % 计算拟合曲线的对应值

figure;
plot(angles, torques0, 'o', 'DisplayName', '原始数据'); % 绘制散点
hold on;
plot(fit_angles, fit_torques0, '-', 'DisplayName', '拟合曲线'); % 绘制拟合曲线
xlabel('角度，单位度');
ylabel('回复力矩，单位N/cm');
title('y轴的回复力矩');
legend;
grid on;

figure;
plot(angles, torques1, 'o', 'DisplayName', '原始数据'); % 绘制散点
hold on;
plot(fit_angles, fit_torques1, '-', 'DisplayName', '拟合曲线'); % 绘制拟合曲线
xlabel('角度，单位度');
ylabel('回复力矩，单位N/cm');
title('x轴的回复力矩');
legend;
grid on;
disp('别急...');
end